# Simple-PHP-Shopping-Cart
Simple PHP shopping cart application for beginners.

![Drag Racing](https://wallpapernoon.com/wp/thumb/shopping_cart_wallpapers_922_3a693_wallpaper.jpg)<br>
[Source](https://wallpapernoon.com/922/shopping-cart-wallpapers)


## Step #1
Run the create-products.sql script and change the connection string in your script to your database.

Read tutorial here
 http://www.tutsplanet.com/simple-php-shopping-cart/
