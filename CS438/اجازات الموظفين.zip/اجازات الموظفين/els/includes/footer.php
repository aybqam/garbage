<footer>
        <div class="footer-area">
                <p>© <?php echo date("Y");?> | للمزيد من المشاريع  |<a href="https://tech-code24.net/">اضغط هنا</a></p>
        </div>
</footer>