<div class="user-profile pull-right">
         <img class="avatar user-thumb" src="../assets/images/avatar.jpg" alt="avatar">
        <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php include 'logged.php' ?> <i class="fa fa-angle-down"></i></h4>
         <div class="dropdown-menu">
            <a class="dropdown-item" href="my-profile.php">عرض الملف الشخصي</a>
            <a class="dropdown-item" href="change-password-employee.php">كلمة المرور</a>
            <a class="dropdown-item" href="logout.php">تسجيل خروج</a>
     </div>
</div>