<!DOCTYPE html>
<html>

<head>
    <title>Display ShoppingCart</title>
</head>

<body>

    <h2>You need to add an SQL statement to insert the following book into the database</h2>

    <?php
    try {
        if (!isset($_POST['quantity']))
            throw new Exception("You need to select quantity");
        $book = $_POST['quantity'];
        if (empty($_POST['quantity']))
            throw new Exception("You need to enter quantity");
        $isbn = $_GET["isbn"];
        echo ("You selected $book Book(s) ISBN= $isbn ");

    }
    //catch exception
    catch (Exception $e) {
        echo 'Message: ' . $e->getMessage();
    }
    ?>
</body>

</html>