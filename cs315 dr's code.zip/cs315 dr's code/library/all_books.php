<!DOCTYPE html>
<html>

<head>
  <title>Display all books from Database</title>
</head>

<body>

  <h2>Books Details</h2>
  <form action="AddToChart.php" method="post" enctype="multipart/form-data">

    <table border="2">
      <tr>
        <td>ISBN</td>
        <td>Author Name</td>
        <td>Title</td>
        <td>Price</td>
        <td>Edit</td>
        <td>Delete</td>
      </tr>

      <?php

      require_once 'dbConn.php';
      $conn = new mysqli($hn, $un, $pw, $db); // Using database connection file here
      if ($conn->connect_error) {
        echo '<p>Error: Could not connect to database.<br/>
    Please try again later.<br/></p>';
        echo $conn->error;
        exit;
      }
      $query = "SELECT ISBN, Author, Title, Price FROM Books";
      //echo $query;
      
      $result = $conn->query($query);
      if (!$result) {
        echo "<p>Unable to execute the query.</p> ";
        echo $query;
        die($conn->error);
      }
      // fetch data from database
      
      while ($data = $result->fetch_array(MYSQLI_ASSOC)) {
        ?>
        <tr>
          <td>
            <?php echo $data['ISBN']; ?>
          </td>
          <td>
            <?php echo $data['Author']; ?>
          </td>
          <td>
            <?php echo $data['Title']; ?>
          </td>
          <td>
            <?php echo $data['Price']; ?>
          </td>
          <td><a href="edit.php?isbn=<?php echo $data['ISBN']; ?>">Edit</a></td>
          <td><a href="delete.php?isbn=<?php echo $data['ISBN']; ?>">Delete</a></td>
          </td>

        </tr>
        <?php
      }
      ?>
    </table>
    <p><input type="submit" value="Add To Chart" /></p>

  </form>
</body>

</html>