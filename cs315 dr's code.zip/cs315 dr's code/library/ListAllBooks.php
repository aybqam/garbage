<?php
require_once 'dbConn.php';
$conn = new mysqli($hn, $un, $pw, $db); // Using database connection file here
if ($conn->connect_error) {
    echo '<p>Error: Could not connect to database.<br/>
    Please try again later.<br/></p>';
    echo $conn->error;
    exit;
}
$product_array = $conn->query("SELECT * FROM Books");
if (!$product_array) {
    echo "<p>Unable to execute the query.</p> ";
    echo $query;
    die($conn->error);
}
if (!empty($product_array)) {
    while ($data = $product_array->fetch_array(MYSQLI_ASSOC)) {
        ?>
        <div class="product-item">
            <form method="post" action="AddToCart.php?isbn=<?php echo $data["ISBN"]; ?>">
                <div>
                    <div>
                        <?php echo $data["ISBN"]; ?>
                    </div>
                    <div>
                        <?php echo $data["Author"]; ?>
                    </div>
                    <div>
                        <?php echo $data["Title"]; ?>
                    </div>
                    <div>
                        <?php echo "$" . $data["Price"]; ?>
                    </div>
                    <div><input type="text" name="quantity" value="1" size="2" />
                        <input type="submit" value="Add to Cart" class="btnAddAction" />
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
}
?>