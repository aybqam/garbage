<!DOCTYPE html>
<html>
<head>
  <title>Tripoli Library Search Results</title>
</head>
<body>
  <h1>Tripoli Library Search Results</h1>
  <?php
    // create short variable names
    $searchtype=$_POST['searchtype'];
    $searchterm=$_POST['searchterm'];

    if (!$searchtype || !$searchterm) {
       echo '<p>You have not entered search details.<br/>
       Please go back and try again.</p>';
       exit;
    }

    // whitelist the searchtype
    switch ($searchtype) {
      case 'Title':
      case 'Author':
      case 'ISBN':   
        break;
      default: 
        echo '<p>That is not a valid search type. <br/>
        Please go back and try again.</p>';
        exit; 
    }
    require_once 'dbConn.php';
    $connection = new mysqli($hn, $un, $pw, $db);

    if ($connection->connect_error) {
       echo '<p>Error: Could not connect to database.<br/>
       Please try again later.<br/></p>';
       echo $connection -> error;
       exit;
    }

    $query = "SELECT ISBN, Author, Title, Price FROM Books WHERE $searchtype Like  '%$searchterm%'  ";
   echo $query;

    $result = $connection->query($query);
    if (!$result) 
    {
        echo "<p>Unable to execute the query.</p> ";
        echo $query;
        die ($connection -> error);
    }

    echo "<p>Number of books found: ".$result->num_rows."</p>";
    $rows = $result->num_rows;
    for ($j = 0 ; $j < $rows ; ++$j)
    {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        echo "<p><strong>Title: " .  $row['Title'] . "</strong>";
        echo "<br />Author: " . $row['Author'] ;
        echo "<br />ISBN: ".  $row['ISBN'];
        echo "<br />Price: ". number_format($row['Price'],2) ." LYD </p>";
    }

    $connection->close();
  ?>
</body>
</html>
