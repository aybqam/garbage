<?php // connection_info.php
    $hn = 'localhost';
    $db = 'library';
    $un = 'root';
    $pw = '';
?>