<?php

require_once 'dbConn.php'; // Using database connection file here
$conn = new mysqli($hn, $un, $pw, $db);

$isbn = $_GET['isbn']; // get id through query string

$query = "SELECT ISBN, Author, Title, Price FROM Books WHERE ISBN =  '$isbn'  "; // select query
//echo $query;

$result = $conn->query($query); // fetch data
if (!$result) {
    echo "<p>Unable to execute the query.</p> ";
    echo $query;
    die($conn->error);
}
$data = $result->fetch_array(MYSQLI_ASSOC);
if (isset($_POST['update'])) // when click on Update button
{
    $author = $_POST['Author'];
    $title = $_POST['Title'];
    $price = $_POST['Price'];

    $query = "update Books set Author='$author', Title='$title', Price=$price where ISBN='$isbn'";
    $edit = $conn->query($query);

    if ($edit) {
        $conn->close(); // Close connection
        header("location:all_books.php"); // redirects to all records page
        exit;
    } else {
        echo "<p>Unable to execute the query.</p> ";
        echo $query;
        die($conn->error);
    }
}
?>

<h3>Update Data</h3>

<form method="POST">
    <input type="text" name="Author" value="<?php echo $data['Author'] ?>" placeholder="Enter Author Name" Required>
    <input type="text" name="Title" value="<?php echo $data['Title'] ?>" placeholder="Enter Title" Required>
    <input type="text" name="Price" value="<?php echo $data['Price'] ?>" placeholder="Enter Price" Required>

    <input type="submit" name="update" value="Update">
</form>