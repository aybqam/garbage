<?php
function IsChecked($chkname, $value)
{
    if (!empty($_POST[$chkname])) {
        foreach ($_POST[$chkname] as $chkval) {
            if ($chkval == $value) {
                return true;
            }
        }
    }
    return false;
}
$sBook = $_POST['row1'];

if (empty($sBook)) {
    echo ("You didn't select any buildings.");
} else {
    $N = count($sBook);

    echo ("You selected $N door(s): " . "<br>");
    for ($i = 0; $i < $N; $i++) {
        // echo (IsChecked('BookSelected', $sBook[$i]));
        $v = $sBook[$i];
        echo ($v . "<br>");
        //  
        // echo ($qBook[$i] . " ");

    }
}
?>