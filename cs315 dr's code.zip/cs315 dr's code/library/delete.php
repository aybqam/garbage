<?php

require_once 'dbConn.php'; // Using database connection file here
$conn = new mysqli($hn, $un, $pw, $db);

$isbn = $_GET['isbn']; // get id through query string

$query = "SELECT ISBN, Author, Title, Price FROM Books WHERE ISBN =  '$isbn'  "; // select query
   //echo $query;

   $result = $conn->query($query);// fetch data
   if (!$result) 
   {
       echo "<p>Unable to execute the query.</p> ";
       echo $query;
       die ($conn -> error);
   }
   $data = $result->fetch_array(MYSQLI_ASSOC);
if(isset($_POST['delete'])) // when click on Update button
{


     $query ="Delete from Books where ISBN='$isbn'";
    $delete =  $conn->query($query);

    if($delete)
    {
        $conn->close();// Close connection
        header("location:all_books.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo "<p>Unable to execute the query.</p> ";
        echo $query;
        die ($conn -> error);
    }    	
}
?>

<h3>Delete Book</h3>

<form method="POST">
  <input type="text" name="Author" value="<?php echo $data['Author'] ?>"  disabled>
  <input type="text" name="Title" value="<?php echo $data['Title'] ?>" disabled>
  <input type="text" name="Price" value="<?php echo $data['Price'] ?>" disabled>

  <input type="submit" name="delete" value="Delete">
</form>