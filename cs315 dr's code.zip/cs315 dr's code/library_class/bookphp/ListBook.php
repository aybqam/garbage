<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class/bookphp/Book.php";
class ListBooks {

    private $listBook = [];
    public function __construct() {
        $this->listBook = array();
        $book1 = new Book("00001", "Cocina", "Comiendo", 20);
        $book2 = new Book("00002", "Computacion", "Programacion", 30);
        $book3 = new Book("00003", "Redes", "Cisco", 40);
        array_push($this->listBook, $book1, $book2, $book3);

    }

    public function insert_book(Book $book){
        $this->listBook[] = $book;
    }
    function getBooks() {

        echo"<table border=1>";
        echo"<tr>";
             echo"<td>ISBN</td>";
             echo"<td>Title</td>";
             echo"<td>Author</td>";
             echo"<td>Price</td>";
        echo"</tr>";

        foreach ($this->listBook as $book) {
            echo"<tr>";
            $isbn=$book->get_book_isbn();
            $title=$book->get_book_title();
            $author=$book->get_book_author();
            $price=$book->get_book_price();

            echo"<td>  $isbn <br/></td>";
            echo"<td>  $title <br/></td>";
            echo"<td>  $author <br/></td>";
            echo"<td>  $price <br/></td>";

            echo"</tr>";

        }

        echo"</table>";
        echo"<ul>";
    }

}










?>