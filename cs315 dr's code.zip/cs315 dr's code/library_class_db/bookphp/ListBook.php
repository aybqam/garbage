<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/Book.php";
class ListBooks
{

    private $listBook = [];
    public function __construct()
    {
        $this->listBook = array();
        //   $book1 = new Book("00001", "Cocina", "Comiendo", 20);
        //   $book2 = new Book("00002", "Computacion", "Programacion", 30);
        //    $book3 = new Book("00003", "Redes", "Cisco", 40);
        //   array_push($this->listBook, $book1, $book2, $book3);

    }

    public function insert_book(Book $book)
    {
        try {
            // $this->listBook[] = $book;
            $isbn = $book->get_book_isbn();
            $author = $book->get_book_author();
            $title = $book->get_book_title();
            $price = $book->get_book_price();
            $query = "INSERT INTO Books (ISBN, Author, Title, Price)  VALUES 
                    ( '$isbn', '$author', '$title', $price)";
            //connect database
            $myDB = new Database();
            //open connection
            $conn = $myDB->establishConnection();
            //execute sql statement
            $mySqlServices = new SqlServices($conn);
            $result = $mySqlServices->insert_record($query);
            echo "<p>Book inserted into the database.</p>";

        } catch (Exception $e) {
            //catch exception
            echo '<BR>Message: ' . $e->getMessage();
        } finally {
            $myDB->closeConnection();
        }
    }
    function display_books($searchtype, $searchterm)
    {
        try {
            $query = "SELECT ISBN, Author, Title, Price FROM Books 
            WHERE $searchtype Like  '%$searchterm%'  ";
            //create a db object
            $myDB = new Database();
            $conn = $myDB->establishConnection();
            $mySqlServices = new SqlServices($conn);
            $result = $mySqlServices->query($query);
            //echo $query;
            echo "<p>Number of books found: " . $result->num_rows . "</p>";
            $rows = $result->num_rows;
            for ($j = 0; $j < $rows; ++$j) {
                $row = $result->fetch_array(MYSQLI_ASSOC);
                echo ("book-" . $j);
                echo "<p><strong>Title: " . $row['Title'] . "</strong>";
                echo "<br />Author: " . $row['Author'];
                echo "<br />ISBN: " . $row['ISBN'];
                echo "<br />Price: " . number_format($row['Price'], 2) . " LYD </p>";

            }
        } catch (Exception $e) {
            //catch exception
            echo '<BR>Message: ' . $e->getMessage();
        } finally {
            $myDB->closeConnection();
        }
    }
    function get_books($searchtype, $searchterm)
    {
        try {
            $query = "SELECT ISBN, Author, Title, Price FROM Books 
            WHERE $searchtype Like  '%$searchterm%'  ";
            echo $query;
            //create a db object
            $myDB = new Database();
            $conn = $myDB->establishConnection();
            $mySqlServices = new SqlServices($conn);
            $result = $mySqlServices->query($query);
            //echo $query;
            echo "<p>Number of books found: " . $result->num_rows . "</p>";
            $rows = $result->num_rows;
            for ($j = 0; $j < $rows; ++$j) {
                $row = $result->fetch_array(MYSQLI_ASSOC);
                $book1 = new Book($row['ISBN'], $row['Title'], $row['Author'], number_format($row['Price'], 2));
                $this->listBook[] = $book1;
            }
            return $this->listBook;

        } catch (Exception $e) {
            //catch exception
            echo '<BR>Message: ' . $e->getMessage();
        } finally {
            $myDB->closeConnection();
        }
    }
    function get_book_by_isbn($isbn)
    {
        try {
            $query = "SELECT ISBN, Author, Title, Price FROM Books 
            WHERE isbn=  '$isbn'  ";
            //echo $query;
            //create a db object
            $myDB = new Database();
            $conn = $myDB->establishConnection();
            $mySqlServices = new SqlServices($conn);
            $result = $mySqlServices->query($query);
            //echo $query;
            echo "<p>Number of books found: " . $result->num_rows . "</p>";
            $rows = $result->num_rows;
            for ($j = 0; $j < $rows; ++$j) {
                $row = $result->fetch_array(MYSQLI_ASSOC);
                $book1 = new Book($row['ISBN'], $row['Title'], $row['Author'], number_format($row['Price'], 2));
                $this->listBook[] = $book1;
            }
            return $this->listBook;

        } catch (Exception $e) {
            //catch exception
            echo '<BR>Message: ' . $e->getMessage();
        } finally {
            $myDB->closeConnection();
        }
    }

}










?>