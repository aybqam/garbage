<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/Book.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/BookSql.php";

try {
    $isbn = $_GET['isbn']; // get id through query string
    $bookSql = new BookSql();
    $allBooks = $bookSql->get_books("ISBN", $isbn);
    //display all the books!

    foreach ($allBooks as $book) {
        $isbn = $book->get_book_isbn();
        $author = $book->get_book_author();
        $title = $book->get_book_title();
        $price = $book->get_book_price();
    }


} catch (Exception $e) {
    //catch exception
    echo '<BR>Message: ' . $e->getMessage();
}

?>

<h3>Update Data</h3>

<form method="POST" action="update_book.php">
    <input type="text" name="Author" value="<?php echo $isbn ?>" placeholder="Enter Author Name" Required>
    <input type="text" name="Title" value="<?php echo $title ?>" placeholder="Enter Title" Required>
    <input type="text" name="Price" value="<?php echo $price ?>" placeholder="Enter Price" Required>

    <input type="submit" name="update" value="Update">
</form>