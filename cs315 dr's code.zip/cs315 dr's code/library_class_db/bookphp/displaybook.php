<!DOCTYPE html>
<html>

<head>
    <title>Tripoli Library Search Results</title>
</head>

<body>
    <h1>Tripoli Library Search Results</h1>

    <?php
    require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/Book.php";
    require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/BookSql.php";

    // create short variable names
    try {
        if (
            !isset($_POST['searchtype']) || !isset($_POST['searchterm'])
        ) {
            throw new Exception("<p>You have not entered all the required details.<br />
                        Please go back to SearchBook.html and try again.</p>");
        }
        // create short variable names
        $searchtype = $_POST['searchtype'];
        $searchterm = $_POST['searchterm'];

        $bookSql = new BookSql();
        //display all the books!
    
        $listBooks->display_books($searchtype, $searchterm);


    } catch (Exception $e) {
        //catch exception
        echo '<BR>Message: ' . $e->getMessage();
    }





    ?>
</body>
<!--     
            $book = new Book($row['ISBN'], $row['Author'], $row['Title'], $row['Price']);
            $book->dispaly_book_details();
-->

</html>