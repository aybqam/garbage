<!DOCTYPE html>
<html>

<head>
    <title>Tripoli Library Search Results</title>
</head>

<body>
    <h1>Tripoli Library Search Results</h1>
    <table border="2">
        <tr>
            <td>ISBN</td>
            <td>Author Name</td>
            <td>Title</td>
            <td>Price</td>
            <td>Edit</td>
            <td>Delete</td>
        </tr>
        <?php
        require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/Book.php";
        require_once $_SERVER["DOCUMENT_ROOT"] . "/library_class_db/bookphp/BookSql.php";

        // create short variable names
        try {
            if (
                !isset($_POST['searchtype']) || !isset($_POST['searchterm'])
            ) {
                throw new Exception("<p>You have not entered all the required details.<br />
                        Please go back to SearchBook.html and try again.</p>");
            }
            $allBooks = array();
            // create short variable names
            $searchtype = $_POST['searchtype'];
            $searchterm = $_POST['searchterm'];
            // whitelist the searchtype
            //display all the books!
            $bookSql = new BookSql();
            $allBooks = $bookSql->get_books($searchtype, $searchterm);
            foreach ($allBooks as $book) {
                $data['ISBN'] = $book->get_book_isbn();
                ?>
                <tr>
                    <td>
                        <?php echo $data['ISBN']; ?>
                    </td>
                    <td>
                        <?php echo $book->get_book_title(); ?>
                    </td>
                    <td>
                        <?php echo $book->get_book_author(); ?>
                    </td>
                    <td>
                        <?php echo $book->get_book_price(); ?>
                    </td>
                    <td><a href="edit.php?isbn=<?php echo $data['ISBN']; ?>">Edit</a></td>
                    <td><a href="delete.php?isbn=<?php echo $data['ISBN']; ?>">Delete</a></td>
                    </td>

                </tr>
                <?php
            }

        } catch (Exception $e) {
            //catch exception
            echo '<BR>Message: ' . $e->getMessage();
        }





        ?>
</body>
<!--     
            $book = new Book($row['ISBN'], $row['Author'], $row['Title'], $row['Price']);
            $book->dispaly_book_details();
-->

</html>