<!DOCTYPE html>
<html>
<body>

<?php
session_start();
if (isset($_SESSION['firstname']))
{
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
    destroy_session_and_data();
    echo ("Welcome back $firstname.");
    echo"<br>" ;
    echo ("Your full name is $firstname $lastname.");
}
else 
    echo "Please <a href='authenticate2.php'>click here</a> to log in.";
function destroy_session_and_data()
{
    // remove all session variables
    session_unset();

    // destroy the session
    session_destroy();
}
?>

</body>
</html>