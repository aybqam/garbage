<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Set session variables 
$_SESSION["firstname"] = "Dr. Ali";
$_SESSION["lastname"] = "Aburas";
echo "Session variables are set.";
?>

</body>
</html>