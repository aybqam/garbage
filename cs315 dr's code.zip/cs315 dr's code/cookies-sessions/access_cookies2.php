<!DOCTYPE html>
<html>
<head>
  <title>Display cookies</title>
</head>
<body>

<?php
$cookie_name = "user";

if(!isset($_COOKIE[$cookie_name])) {
  ?> 
  <h2><?php echo "Cookie named '" . $cookie_name . "' is not set!"; ?></h2>
  <?php
  
} else {

  if( $_COOKIE[$cookie_name]=='Dr. Ali') 
  {
    ?>  
            <h1><?php echo "Welcome back: "  .  $_COOKIE[$cookie_name]; ?></h1>
<?php
  } else {
    ?> 
    <h1><?php echo "You are not Dr. Ali. You are "  .  $_COOKIE[$cookie_name]; ?></h1>
    <?php
  }
}
?>

</body>
</html>