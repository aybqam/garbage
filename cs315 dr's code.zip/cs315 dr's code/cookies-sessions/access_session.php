<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Echo session variables that were set on previous page
if (isset($_SESSION['firstname']))
{
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
    echo "Welcome back $lastname.<br> Your full name is $firstname $lastname.<br>";
}
else echo "Please <a href=authenticate2.php>click here</a> to log in.";
?>

</body>
</html>