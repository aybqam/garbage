<!DOCTYPE html>
<html>
<head>
    <title>Shooping Cart</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="bootstrap.min.css" />
    <link rel="stylesheet" href="cart.css" />
    <script type="text/javascript" src="bootstrap.min"></script>
</head> 
<body>
  <div class="container text-center">
	<h1 style="color:#22222;">Davinci php BootCamp</h1>
<br/>
   <a href="cart.php" >
    <div class="btn btn-warning">Start Script</div>
</a>
    </div>
    </body>
    