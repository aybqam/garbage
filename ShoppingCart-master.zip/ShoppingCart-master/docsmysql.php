<?php
/* Cart Project DoCs */
    /* Create Tables Query */
/*
  CREATE TABLE products (
 id int(11) NOT NULL AUTO_INCREMENT,
 name VARCHAR(255) CHARACTER SET utf8 NOT NULL,
 image varchar(255) NOT NULL,
 price float NOT NULL,
 PRIMARY KEY (id));
 ----------------------------------------------------------
 ==-=-=-=-=-=-=-=-=-=-=-=-=-=\
 INSERT INTO products (id,name,price,image) VALUES
(1,'Intel Core i7-8700k Coffe Lake 6-Core 3.8 GHz',414.99,'imageon'),
(2,'Corsair Crystal 570X RGB ATX MID TOWER CASE',197.99,'imagetow.png'),
(3,'Corsair Gaming Mouse SCIMITAR PRO RGB',79.99,'imagethree.png'),
(4,'G.SKILL TridentZ RGB Series 32GB DDr4',439.99,'imagefor.png');
----------------------------------------------------------
 ==-=-=-=-=-=-=-=-=-=-=-=-=-=\
 */