package com.example.listview_builder_with_image_and_text

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
