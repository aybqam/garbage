<?php

// Start the session 
session_start();

// Database connection info
$servername = "localhost";
$username = "root";  
$password = "";
$dbname = "ecommerce";

// Create connection with the database name
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
    die("Connection failed: ". $con->connect_error);
}

    
    
// Handle sign-in form submission
if (isset($_POST['sign-in'])) {

    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $useCookie = isset($_POST['use-cookie'])? true : false;

    $user = explode("@", $email)[0];

    // Check if table exists
    $users = $user. "_users";
    $Favorites = $user. "_Favorites";
    $cart = $user. "_cart";

    $_SESSION['users'] = $users;
    $_SESSION['Favorites'] = $Favorites;
    $_SESSION['cart'] = $cart;

    // Check for admin credentials
    if ($email === 'admin@gmail.com' && $password === 'admin') {
        header("Location: message.php");
        exit();
    }

    $showTablesQuery = "SHOW TABLES LIKE '$users'";
    $result = mysqli_query($con, $showTablesQuery);

    // If table does not exist, show error message
    if (mysqli_num_rows($result) == 0) {
        $error2 = "Account does not exist";
    } else {
        $row = mysqli_fetch_assoc($result);
        $result = mysqli_query($con, "SELECT * FROM $users WHERE Email='$email'");
        $row = mysqli_fetch_assoc($result);
        if (is_array($row) &&!empty($row)) {
            if (password_verify($password, $row['Password'])) {
                $_SESSION['valid'] = $row['Email'];
                $_SESSION['username'] = $row['Username'];
                $_SESSION['id'] = $row['Id'];
                if ($useCookie) {
                    setcookie("user_cookie", $row['Email'], time() + (30 * 24 * 60 * 60), "/");
                }
                header("Location: index.php");
                exit();
            } else {
                $error2 = "Wrong Email or Password";
            }
        } else {
            $error2 = "Wrong Email or Password";
        }
    }
}



if (isset($_POST['sign-up'])) {

    $username = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    $messages = "CREATE TABLE IF NOT EXISTS messages (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        Usernames VARCHAR(50) NOT NULL,
        Emails VARCHAR(50) NOT NULL,
        message VARCHAR(255) NOT NULL
    )";
    mysqli_query($con, $messages);

    // Extract the user part from the email
    $user = explode("@", $email)[0];

    // Define table names
    $usersTable = $user . "_users";
    $favoritesTable = $user . "_Favorites";
    $cartTable = $user . "_cart";

    // Function to create a table if it doesn't exist
    function createTableIfNotExists($con, $tableName, $createQuery) {
        $showTablesQuery = "SHOW TABLES LIKE '$tableName'";
        $result = mysqli_query($con, $showTablesQuery);
        if (mysqli_num_rows($result) == 0) {
            mysqli_query($con, $createQuery);
        }
    }

    // Create user-specific tables if they don't exist
    createTableIfNotExists($con, $usersTable, "CREATE TABLE $usersTable (
        Id INT PRIMARY KEY AUTO_INCREMENT,
        Username VARCHAR(200),
        Email VARCHAR(200),
        Password VARCHAR(200)
    )");

    createTableIfNotExists($con, $favoritesTable, "CREATE TABLE $favoritesTable (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200),
        price DECIMAL(10,2),
        image VARCHAR(200)
    )");

    createTableIfNotExists($con, $cartTable, "CREATE TABLE $cartTable (
        id INT PRIMARY KEY AUTO_INCREMENT,
        product_name VARCHAR(255),
        price DECIMAL(10, 2),
        size VARCHAR(10),
        color VARCHAR(20),
        quantity INT,
        image VARCHAR(200)
    )");

    // Validate input
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Please fill all the fields";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } elseif  (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
        $error = "Password must contain 8 characters with at any least uppercase letter, any lowercase letter, and any number";
    } else {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if email is already taken
        $stmt = $con->prepare("SELECT Email FROM $usersTable WHERE Email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows > 0) {
            $error = "This email is already taken, please try another one";
        } else {
            // Insert user into database
            $stmt = $con->prepare("INSERT INTO $usersTable (Username, Email, Password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);

            if ($stmt->execute()) {
                $stmt->close();
                // Insert into messages table
                $message = "Welcome to our service!"; // Define the welcome message
                $stmt2 = $con->prepare("INSERT INTO messages (Usernames, Emails, message) VALUES (?, ?, ?)");
                $stmt2->bind_param("sss", $username, $email, $message);

                if ($stmt2->execute()) {
                    $stmt2->close();
                    $success = "Registration successful!";
                } else {
                    $stmt2->close();
                    $error = "Error occurred while inserting into messages table";
                }
            } else {
                $stmt->close();
                $error = "Error occurred while inserting into users table";
            }
        }
    }
}


?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#1a75ff">
    <link rel="icon" href="http://tinyurl.com/36h7uvf3">
    <!-- Bootstrap CSS -->

    <!-- Bootstrap Icons CSS -->
    <link rel="stylesheet" href="./CSS/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">


    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- SweetAlert2 -->
    <link href="./CSS/sweetalert2.min.css" rel="stylesheet" type="text/css"/>


<style>

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body,
input {
  font-family: "Poppins", sans-serif;
}

   .alert {
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        
    }

   .alert-success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

   .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }


.container {
  position: relative;
  width: 100%;
  background-color: #fff;
  min-height: 100vh;
  overflow: hidden;
}

.forms-container {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
}

.signin-signup {
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 75%;
  width: 50%;
  transition: 1s 0.7s ease-in-out;
  display: grid;
  grid-template-columns: 1fr;
  z-index: 5;
}

form {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  padding: 0rem 5rem;
  transition: all 0.2s 0.7s;
  overflow: hidden;
  grid-column: 1 / 2;
  grid-row: 1 / 2;
}

form.sign-up-form {
  opacity: 0;
  z-index: 1;
}

form.sign-in-form {
  z-index: 2;
}

.title {
  font-size: 2.2rem;
  color: #444;
  margin-bottom: 10px;
}

.input-field {
  max-width: 380px;
  width: 100%;
  background-color: #f0f0f0;
  margin: 10px 0;
  height: 55px;
  border-radius: 55px;
  display: grid;
  grid-template-columns: 15% 85%;
  padding: 0 0.4rem;
  position: relative;
}

.input-field i {
  text-align: center;
  line-height: 55px;
  color: #acacac;
  transition: 0.5s;
  font-size: 1.1rem;
}

.input-field input {
  background: none;
  outline: none;
  border: none;
  line-height: 1;
  font-weight: 500;
  font-size: 1.1rem;
  color: #333;
}

.input-field input::placeholder {
  color: #aaa;
  font-weight: 500;
}

.input-field-2 {
    width: 100%;
    left: 12%;
    display: grid;
    grid-template-columns: 15% 85%;
    padding: 13px 0.4rem;
    position: relative;
}

@media (min-width: 1440px) {

.input-field-2 {
    width: 100%;
    left: 12%;
    display: grid;
    grid-template-columns: 15% 85%;
    padding: 13px 0.4rem;
    position: relative;
}
  
}
  
@media (min-width: 768px) and (max-width: 1024px) {

 .input-field-2 {
    width: 100%;
    left: 1%;
    display: grid;
    grid-template-columns: 15% 85%;
    padding: 13px 0.4rem;
    position: relative;
}    
      
}
    
  @media (min-width: 425px) and (max-width: 768px) {
  
  .input-field-2 {
    width: 100%;
    left: 16%;
    display: grid;
    grid-template-columns: 15% 85%;
    padding: 13px 0.4rem;
    position: relative;
}
  
}
  
  @media (min-width: 320px) and (max-width: 425px) {
  
  .input-field-2 {
    width: 100%;
    left: 0%;
    display: grid;
    grid-template-columns: 15% 85%;
    padding: 13px 0.4rem;
    position: relative;
}

}

.social-text {
  padding: 0.7rem 0;
  font-size: 1rem;
}

.social-media {
  display: flex;
  justify-content: center;
}

.social-icon {
  height: 46px;
  width: 46px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 0.45rem;
  color: #333;
  border-radius: 50%;
  border: 1px solid #333;
  text-decoration: none;
  font-size: 1.1rem;
  transition: 0.3s;
}

.social-icon:hover {
  color: #4481eb;
  border-color: #4481eb;
}

.btn {
  width: 150px;
  background-color: #5995fd;
  border: none;
  outline: none;
  height: 49px;
  border-radius: 49px;
  color: #fff;
  text-transform: uppercase;
  font-weight: 600;
  margin: 10px 0;
  cursor: pointer;
  transition: 0.5s;
}

.btn:hover {
  background-color: #4d84e2;
}
.panels-container {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
}

.container:before {
  content: "";
  position: absolute;
  height: 2000px;
  width: 2000px;
  top: -10%;
  right: 48%;
  transform: translateY(-50%);
  background-image: linear-gradient(-45deg, #4481eb 0%, #04befe 100%);
  transition: 1.8s ease-in-out;
  border-radius: 50%;
  z-index: 6;
}

.image {
  width: 100%;
  transition: transform 1.1s ease-in-out;
  transition-delay: 0.4s;
}

.panel {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-around;
  text-align: center;
  z-index: 6;
}

.left-panel {
  pointer-events: all;
  padding: 3rem 17% 2rem 12%;
}

.right-panel {
  pointer-events: none;
  padding: 3rem 12% 2rem 17%;
}

.panel .content {
  color: #fff;
  transition: transform 0.9s ease-in-out;
  transition-delay: 0.6s;
}

.panel h3 {
  font-weight: 600;
  line-height: 1;
  font-size: 1.5rem;
}

.panel p {
  font-size: 0.95rem;
  padding: 0.7rem 0;
}

.btn.transparent {
  margin: 0;
  background: none;
  border: 2px solid #fff;
  width: 130px;
  height: 41px;
  font-weight: 600;
  font-size: 0.8rem;
}

.right-panel .image,
.right-panel .content {
  transform: translateX(800px);
}

/* ANIMATION */

.container.sign-up-mode:before {
  transform: translate(100%, -50%);
  right: 52%;
}

.container.sign-up-mode .left-panel .image,
.container.sign-up-mode .left-panel .content {
  transform: translateX(-800px);
}

.container.sign-up-mode .signin-signup {
  left: 25%;
}

.container.sign-up-mode form.sign-up-form {
  opacity: 1;
  z-index: 2;
}

.container.sign-up-mode form.sign-in-form {
  opacity: 0;
  z-index: 1;
}

.container.sign-up-mode .right-panel .image,
.container.sign-up-mode .right-panel .content {
  transform: translateX(0%);
}

.container.sign-up-mode .left-panel {
  pointer-events: none;
}

.container.sign-up-mode .right-panel {
  pointer-events: all;
}

@media (max-width: 870px) {
  .container {
    min-height: 800px;
    height: 100vh;
  }
  .signin-signup {
    width: 100%;
    top: 95%;
    transform: translate(-50%, -100%);
    transition: 1s 0.8s ease-in-out;
  }

  .signin-signup,
  .container.sign-up-mode .signin-signup {
    left: 50%;
  }

  .panels-container {
    grid-template-columns: 1fr;
    grid-template-rows: 1fr 2fr 1fr;
  }

  .panel {
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    padding: 2.5rem 8%;
    grid-column: 1 / 2;
  }

  .right-panel {
    grid-row: 3 / 4;
  }

  .left-panel {
    grid-row: 1 / 2;
  }

  .image {
    width: 200px;
    transition: transform 0.9s ease-in-out;
    transition-delay: 0.6s;
  }

  .panel .content {
    padding-right: 15%;
    transition: transform 0.9s ease-in-out;
    transition-delay: 0.8s;
  }

  .panel h3 {
    font-size: 1.2rem;
  }

  .panel p {
    font-size: 0.7rem;
    padding: 0.5rem 0;
  }

  .btn.transparent {
    width: 110px;
    height: 35px;
    font-size: 0.7rem;
  }

  .container:before {
    width: 1500px;
    height: 1500px;
    transform: translateX(-50%);
    left: 30%;
    bottom: 68%;
    right: initial;
    top: initial;
    transition: 2s ease-in-out;
  }

  .container.sign-up-mode:before {
    transform: translate(-50%, 100%);
    bottom: 32%;
    right: initial;
  }

  .container.sign-up-mode .left-panel .image,
  .container.sign-up-mode .left-panel .content {
    transform: translateY(-300px);
  }

  .container.sign-up-mode .right-panel .image,
  .container.sign-up-mode .right-panel .content {
    transform: translateY(0px);
  }

  .right-panel .image,
  .right-panel .content {
    transform: translateY(300px);
  }

  .container.sign-up-mode .signin-signup {
    top: 5%;
    transform: translate(-50%, 0);
  }
}

@media (max-width: 570px) {
  form {
    padding: 0 1.5rem;
  }

  .image {
    display: none;
  }
  .panel .content {
    padding: 0.5rem 1rem;
  }
  .container {
    padding: 1.5rem;
  }

  .container:before {
    bottom: 72%;
    left: 50%;
  }

  .container.sign-up-mode:before {
    bottom: 28%;
    left: 50%;
  }
}

.input-field-2 input[type="checkbox"] {
  margin-left: 45%;
  width: 16px;
}

.input-field-2 input[type="checkbox"]:checked {
  accent-color: blue;
}

</style>

    <title>Sign in & Sign up Form</title>
  </head>
  <body>
<div class="container">
  <div class="forms-container">
    <div class="signin-signup">
      <form action="" method="post" class="sign-in-form">

        <?php if(isset($error2)): ?>
            <div class="alert alert-danger" role="alert">
                <p><?php echo $error2 ?></p>
            </div>
        <?php endif; ?>

        <h2 class="title">Sign in</h2>
        <div class="input-field">
          <i class="fas fa-user"></i>
          <input type="text" name="email" placeholder="Email" />
        </div>
        <div class="input-field">
          <i class="fas fa-lock"></i>
          <input type="password" id="password-input" name="password" placeholder="Password" />
          <button type="button" id="toggle-password" style="background: none; border: none; position: absolute; right: 10px;"><i class="fas fa-eye-slash"></i></button>
        </div>
        <div class="input-field-2">
          <input type="checkbox" id="use-cookie" name="use-cookie" value="1">
          <label for="use-cookie" style="color:black;">Remember me</label>
        </div>
        <input type="submit" name="sign-in" value="Login" class="btn solid" />
      </form>


      <form action="" method="post" class="sign-up-form">

        <?php if(isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <p><?php echo $error ?></p>
            </div>
        <?php endif; ?>
        <?php if(isset($success)): ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo $success ?></p>
            </div>
        <?php endif; ?>

        <h2 class="title">Sign up</h2>
        <div class="input-field">
          <i class="fas fa-user"></i>
          <input type="text" name="username" placeholder="Username" />
        </div>
        <div class="input-field">
          <i class="fas fa-envelope"></i>
          <input type="email" name="email" placeholder="Email" />
        </div>
        <div class="input-field">
          <i class="fas fa-lock"></i>
          <input type="password" id="password-input-signup" name="password" placeholder="Password" />
          <button type="button" id="toggle-password-signup" style="background: none; border: none; position: absolute; right: 10px;"><i class="fas fa-eye-slash"></i></button>
        </div>
        <input type="submit" name="sign-up" class="btn" value="Sign up" />
      </form>
    </div>
  </div>

  <div class="panels-container">
    <div class="panel left-panel">
      <div class="content">
        <h3>New here ?</h3>
        <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Debitis,
          ex ratione. Aliquid!
        </p>
        <button class="btn transparent" id="sign-up-btn">
          Sign up
        </button>
      </div>
      <img src="http://tinyurl.com/3karndx9" class="image" alt="" />
    </div>
    <div class="panel right-panel">
      <div class="content">
        <h3>One of us ?</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum
          laboriosam ad deleniti.
        </p>
        <button class="btn transparent" id="sign-in-btn">
          Sign in
        </button>
      </div>
      <img src="http://tinyurl.com/yx5ybxr5" class="image" alt="" />
    </div>
  </div>
</div>


      <script>
        
    const sign_in_btn = document.querySelector("#sign-in-btn");
    const sign_up_btn = document.querySelector("#sign-up-btn");
    const container = document.querySelector(".container");

    sign_up_btn.addEventListener("click", () => {
      container.classList.add("sign-up-mode");
    });

    sign_in_btn.addEventListener("click", () => {
      container.classList.remove("sign-up-mode");
    });

    // Check if there are any error or success messages from the sign-up form
    const signUpError = document.querySelector(".sign-up-form .alert-danger");

    if (signUpError) {
      // If there are, keep the sign-up form displayed
      container.classList.add("sign-up-mode");
    }

    const togglePassword = document.querySelector('#toggle-password');
    const passwordInput = document.querySelector('#password-input');

    togglePassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        // toggle the eye slash icon
        this.children[0].classList.toggle('fa-eye-slash');
        this.children[0].classList.toggle('fa-eye');
    });

    const togglePasswordSignup = document.querySelector('#toggle-password-signup');
    const passwordInputSignup = document.querySelector('#password-input-signup');

    togglePasswordSignup.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = passwordInputSignup.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInputSignup.setAttribute('type', type);
        // toggle the eye slash icon
        this.children[0].classList.toggle('fa-eye-slash');
        this.children[0].classList.toggle('fa-eye');
    });

      </script>
  
  </body>
</html>
