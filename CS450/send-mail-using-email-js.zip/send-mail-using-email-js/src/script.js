// User ID
// user_id
// Access Token
// random_access-token

(function () {
  emailjs.init("USERID");
})();

/**
        emailjs.send("SERVICE ID", "TEMPLATE NAME", {
          to_name: "USERNAME",
          from_name: "FROM NAME",
          message: "MESSAGE",
        });
       **/

function validate() {
  let loader = document.querySelector(".loader");
  let name = document.querySelector(".username");
  let email = document.querySelector(".email");
  let msg = document.querySelector(".message");
  let btn = document.querySelector(".submit");

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    if (name.value == "" || email.value == "" || msg.value == "") {
      emptyerror();
    } else {
      loader.style.display = "flex";
      sendmail(name.value, email.value, msg.value);
      success();
      loader.style.display = "none";
    }
  });
}
validate();

function sendmail(name, email, msg) {
  emailjs.send("service_id", "template_name", {
    to_name: "your recipient name",
    from_name: email,
    message: msg
  });
}

function emptyerror() {
  Swal.fire({
    icon: "error",
    title: "Oops...",
    text: "Fields cannot be empty!"
  });
}

function error() {
  Swal.fire({
    icon: "error",
    title: "Oops...",
    text: "Something went wrong!"
  });
}

function success() {
  Swal.fire({
    icon: "success",
    title: "Success...",
    text: "Successfully sent message"
  });
}
