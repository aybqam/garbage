<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include the Composer autoloader
require 'vendor/autoload.php';

// Start the session
session_start();

// Database connection info
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";

// Create connection with the database name
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if (isset($_POST['send'])) {

    // Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    // Sanitize the input
    $message = mysqli_real_escape_string($con, $_POST['message']);

    // Update the message in the database for all records
    $stmt = $con->prepare("UPDATE messages SET message=?");
    $stmt->bind_param("s", $message); // Bind the message parameter
    $stmt->execute();
    $stmt->close(); // Close the statement

    // Perform the SQL query
    $sql = "SELECT Usernames, Emails, message FROM messages";
    $result = $con->query($sql);

    // Check if any rows were returned
    if ($result->num_rows > 0) {

        // Set SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'diorstore97@gmail.com';
        $mail->Password = 'atbrkwpoouimiynl';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        // Set email content
        $mail->isHTML(true);
        $mail->Subject = 'New message from Dior Store';

        // Loop through the rows and add recipients and messages
        while ($row = $result->fetch_assoc()) {
            $username = $row["Usernames"];
            $email = $row["Emails"];
            $message = $row["message"];

            // Add recipient
            $mail->addAddress($email, $username);

            // Add message
            $mail->Body = $message;

            // Send the email
            if ($mail->send()) {
                // Store the result in a session variable
                $_SESSION['email_sent'] = true;
            } else {
                $_SESSION['email_sent'] = false;
            }

            // Clear recipients for the next iteration
            $mail->ClearAllRecipients();
        }
    } else {
        echo "No results found.";
    }

    // Close the connection
    $con->close();

    // Redirect back to the first page
    header("Location: message.php");
    exit();
}
?>