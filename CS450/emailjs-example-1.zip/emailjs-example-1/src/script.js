
(function(){
  emailjs.init("user_woxhswz7BPydWBckoHbDA");
})();

let info = {
  from: null,
  to: null,
  message: null
};

const getInfo = function() {
  info.from = document.getElementById('from').value;
  info.to = document.getElementById('to').value;
  info.message = document.getElementById('message').value;
  console.log(info);
};

const sendEmail = function() {
  getInfo();
  emailjs.send("gmail", "template_bKkmQm7z", {
    from_name: info.from,
    to_name: info.to, 
    message_html: info.message
    }).then(function(response) {
      console.log("SUCCESS. status=%d, text=%s", response.status, response.text);
    }, function(err) {
     console.log("FAILED. error=", err);
    }
  );
};
